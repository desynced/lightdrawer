LIGHTDRAWER RECEIPT

File: harbor-photo.jpg (17446 bytes)
SHA-256: fb7ee462b3fae86543b221ed4ae4b847085bcded27e026e86d37783509cd139c
Statement SHA-256: 5a445c3cceda7dccfa92c0876c713537d8b26c8a52a911a7322d1c908e6f26e8

In one sentence: a file with this fingerprint existed no later than the times below. That is all this receipt proves.

WHAT IS PROVEN, AND WHEN
- RFC 3161 timestamp from FreeTSA (freetsa.org): 2026-11-09 16:15:20 UTC
  Signed by one third-party timestamp authority. Checkable now.
- OpenTimestamps → Bitcoin: Pending when made
  Calendars put the hash into a Bitcoin transaction, usually within ~1–6 hours. Upgrade the proof after that; then nobody needs to be trusted except the Bitcoin chain.

WHAT THIS DOES NOT PROVE
- It proves the file (and this statement) existed no later than the times above. The file may be older.
- It does not prove who made the file, that it is authentic, unedited before stamping, or that what it shows is true.
- Provenance fields are the collector's own statements, fixed in time by the stamps, not verified facts.
- Hash only: the file is not stored anywhere by LightDrawer. Keep the original. Lose it and the receipt can no longer be tied to any content. Changing one bit changes the hash.
- FreeTSA is a single authority: you trust its key. Bitcoin anchoring removes that once confirmed. Rekor is run by Sigstore/OpenSSF.
- C2PA Content Credentials, if noted, were read but not validated.

HOW TO VERIFY WITHOUT LIGHTDRAWER
* Check your file
    sha256sum "harbor-photo.jpg"
  Must print fb7ee462b3fae86543b221ed4ae4b847085bcded27e026e86d37783509cd139c. If not, this receipt is not about your file.

* Check the statement
    sha256sum statement.json
  Must print 5a445c3cceda7dccfa92c0876c713537d8b26c8a52a911a7322d1c908e6f26e8. Every proof below is about this hash.

* RFC 3161 (OpenSSL)
    openssl ts -verify -data statement.json -in proofs/statement.json.tsr -CAfile trust/freetsa-cacert.pem -untrusted trust/freetsa-tsa.crt
  Prefer certificates downloaded yourself from https://freetsa.org/files/. Root SHA-256 fingerprint: a6379e7cecc05faa3cbf076013d745e327bbbaa38c0b9af22469d4701d18aabc.

* OpenTimestamps
    pip install opentimestamps-client
    ots upgrade proofs/statement.json.ots
    ots verify -f statement.json proofs/statement.json.ots
  Or drop statement.json and the .ots file on https://opentimestamps.org. "Pending" just means Bitcoin has not confirmed yet; try again in a few hours. `ots verify` needs a Bitcoin node, or use the website.

* All at once, offline
    Open verify.html in any modern browser
  Drop this ZIP (and optionally the original file). It re-hashes and checks every proof without contacting LightDrawer.

LightDrawer does not store or publish files. Archive public sources yourself (perma.cc, web.archive.org/save, Arweave).
