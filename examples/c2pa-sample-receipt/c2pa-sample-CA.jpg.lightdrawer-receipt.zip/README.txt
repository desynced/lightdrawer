LIGHTDRAWER RECEIPT

File: 03-c2pa-sample-CA.jpg (166864 bytes)
SHA-256: e71bff58fc57640803e6e65f7534e2fb0c2f99018c85276cc14b30f04427cc76
Statement SHA-256: 19dc6f4e665d7675b6a107bb11097245322d6c5b98599b9058d7e48ae582b260

In one sentence: a file with this fingerprint existed no later than the times below. That is all this receipt proves.

WHAT IS PROVEN, AND WHEN
- RFC 3161 timestamp from FreeTSA (freetsa.org): 2026-11-10 17:55:08 UTC
  Signed by one third-party timestamp authority. Checkable now.
- OpenTimestamps → Bitcoin: Pending when made
  Calendars put the hash into a Bitcoin transaction, usually within ~1–6 hours. Upgrade the proof after that; then nobody needs to be trusted except the Bitcoin chain.
- Certificate Transparency (public HTTPS certificate logs): Pending when made
  LightDrawer batches fingerprints and names a later certificate after the batch root. Those certificates appear in public Certificate Transparency logs. This is an extra witness, not a replacement for Bitcoin.

WHAT THIS DOES NOT PROVE
- It proves the file (and this statement) existed no later than the times above. The file may be older.
- It does not prove who made the file, that it is authentic, unedited before stamping, or that what it shows is true.
- Provenance fields are the collector's own statements, fixed in time by the stamps, not verified facts.
- Hash only: the file is not stored anywhere by LightDrawer. Keep the original. Lose it and the receipt can no longer be tied to any content. Changing one bit changes the hash.
- FreeTSA is a single authority: you trust its key. Bitcoin anchoring removes that once confirmed. Rekor is run by Sigstore/OpenSSF. The certificate-log stamp depends on Let's Encrypt and public CT logs remaining available (crt.sh and other archives keep copies). It is an extra witness, not a replacement for Bitcoin.
- C2PA Content Credentials, if noted, were read but not validated.

HOW TO VERIFY WITHOUT LIGHTDRAWER
* Check your file
    sha256sum "03-c2pa-sample-CA.jpg"
  Must print e71bff58fc57640803e6e65f7534e2fb0c2f99018c85276cc14b30f04427cc76. If not, this receipt is not about your file.

* Check the statement
    sha256sum statement.json
  Must print 19dc6f4e665d7675b6a107bb11097245322d6c5b98599b9058d7e48ae582b260. Every proof below is about this hash.

* RFC 3161 (OpenSSL)
    openssl ts -verify -data statement.json -in proofs/statement.json.tsr -CAfile trust/freetsa-cacert.pem -untrusted trust/freetsa-tsa.crt
  Prefer certificates downloaded yourself from https://freetsa.org/files/. Root SHA-256 fingerprint: a6379e7cecc05faa3cbf076013d745e327bbbaa38c0b9af22469d4701d18aabc.

* OpenTimestamps
    pip install opentimestamps-client
    ots upgrade proofs/statement.json.ots
    ots verify -f statement.json proofs/statement.json.ots
  Or drop statement.json and the .ots file on https://opentimestamps.org. "Pending" just means Bitcoin has not confirmed yet; try again in a few hours. `ots verify` needs a Bitcoin node, or use the website.

* Certificate Transparency
    See HOW-IT-WORKS.md: check proofs/ct.json, recompute the Merkle root from digest + path, confirm the certificate SAN encodes that root, then look the hostname up on https://crt.sh
  Pending means the batch has not been written into a certificate yet. The offline verifier can upgrade this the same way it upgrades an OpenTimestamps proof.

* All at once, offline
    Open verify.html in any modern browser
  Drop this ZIP (and optionally the original file). It re-hashes and checks every proof without contacting LightDrawer.

LightDrawer does not store or publish files. Archive public sources yourself (perma.cc, web.archive.org/save, Arweave).
