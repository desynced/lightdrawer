TIMESTAMP RECEIPT

File: selftest.txt (47 bytes)
SHA-256: 3eb350df8fb833e57d3ee572bac8c8113c3499c72280dacd85b30bb210e36b4a
Statement SHA-256: e83a24bd57223f9fda6e6b385973233fb4cf807f5424c68ebbc5c83ae6116b33

In one sentence: a file with this SHA-256 existed no later than the times below. That is all this receipt proves.

WHAT IS PROVEN, AND WHEN
- RFC 3161 timestamp from FreeTSA (freetsa.org): 2026-11-09 13:47:57 UTC
  Signed by one third-party timestamp authority. Checkable now.
- OpenTimestamps → Bitcoin: Pending when made
  Calendars put the hash into a Bitcoin transaction, usually within ~1–6 hours. Upgrade the proof after that; then nobody needs to be trusted except the Bitcoin chain.

PROVENANCE (collector's statements)
- framework: Berkeley Protocol on Digital Open Source Investigations (fields are the collector's own statements)
- source_url: https://example.org/post/1
- collected_at: 2026-11-09T07:40:00-06:00
- collector: self-test
- collection_method: test/run.mjs
- collector_notes: Synthetic test file.

WHAT THIS DOES NOT PROVE
- It proves the file (and this statement) existed no later than the times above. The file may be older.
- It does not prove who made the file, that it is authentic, unedited before stamping, or that what it shows is true.
- Provenance fields are the collector's own statements, fixed in time by the stamps, not verified facts.
- Hash only: the file is not stored anywhere by LightDrawer. Keep the original. Lose it and the receipt can no longer be tied to any content. Changing one bit changes the hash.
- FreeTSA is a single authority: you trust its key. Bitcoin anchoring removes that once confirmed. Rekor is run by Sigstore/OpenSSF.
- C2PA Content Credentials, if noted, were read but not validated.

HOW TO VERIFY WITHOUT LIGHTDRAWER
* Check your file
    sha256sum "selftest.txt"
  Must print 3eb350df8fb833e57d3ee572bac8c8113c3499c72280dacd85b30bb210e36b4a. If not, this receipt is not about your file.

* Check the statement
    sha256sum statement.json
  Must print e83a24bd57223f9fda6e6b385973233fb4cf807f5424c68ebbc5c83ae6116b33. Every proof below is about this hash.

* RFC 3161 (OpenSSL)
    openssl ts -verify -data statement.json -in proofs/statement.json.tsr -CAfile trust/freetsa-cacert.pem -untrusted trust/freetsa-tsa.crt
  Prefer certificates downloaded yourself from https://freetsa.org/files/. Root SHA-256 fingerprint: a6379e7cecc05faa3cbf076013d745e327bbbaa38c0b9af22469d4701d18aabc.

* OpenTimestamps
    pip install opentimestamps-client
    ots upgrade proofs/statement.json.ots
    ots verify -f statement.json proofs/statement.json.ots
  Or drop statement.json and the .ots file on https://opentimestamps.org. "Pending" just means Bitcoin has not confirmed yet; try again in a few hours. `ots verify` needs a Bitcoin node, or use the website.

* All at once, offline
    Open verify.html in any modern browser
  Drop this ZIP (and optionally the original file). It re-hashes and checks every proof without contacting LightDrawer.

LightDrawer does not store or publish files. Archive public sources yourself (perma.cc, web.archive.org/save, Arweave).
